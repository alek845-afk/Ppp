package ru.sluzhbakorony;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

public class EntityRoyalMessenger extends EntityCreature {
    private boolean delivered = false;

    public EntityRoyalMessenger(World world) {
        super(world);
        this.setSize(0.6F, 1.95F);
    }

    @Override
    protected void initEntityAI() {
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, new EntityAIAvoidEntity<EntityPlayer>(this, EntityPlayer.class, 5.0F, 0.0D, 0.0D));
        this.tasks.addTask(2, new EntityAIMoveIndoors(this));
        this.tasks.addTask(3, new EntityAIMoveTowardsRestriction(this, 0.6D));
        this.tasks.addTask(4, new EntityAIWander(this, 0.45D));
        this.tasks.addTask(5, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(6, new EntityAILookIdle(this));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(24.0D);
    }

    @Override
    protected boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (!this.world.isRemote && !delivered) {
            delivered = true;
            player.sendMessage(new TextComponentString(
                "§6Королевский посланник: §f«По приказу Его Величества ты обязан явиться во дворец. Корона призывает тебя на службу!»"
            ));
            player.sendMessage(new TextComponentString(
                "§eНовое задание: §fНайди королевский замок и поговори с королём. (Следующая глава сюжета появится в обновлении.)"
            ));
            this.setCustomNameTag("Королевский посланник");
            this.setAlwaysRenderNameTag(true);
        }
        return true;
    }

    @Override
    protected boolean canDespawn() {
        return false;
    }
}
