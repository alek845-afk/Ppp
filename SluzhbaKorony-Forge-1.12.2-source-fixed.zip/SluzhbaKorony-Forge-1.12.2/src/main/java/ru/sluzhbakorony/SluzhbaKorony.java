package ru.sluzhbakorony;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraft.util.ResourceLocation;

@Mod(modid = SluzhbaKorony.MODID, name = "Служба Короны", version = "1.0.0")
public class SluzhbaKorony {
    public static final String MODID = "sluzhbakorony";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        EntityRegistry.registerModEntity(
            new ResourceLocation(MODID, "royal_messenger"),
            EntityRoyalMessenger.class,
            "royal_messenger",
            1, this, 64, 3, true, 0x263B65, 0xD6B45C
        );
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        // Сюжетные события и регистрация контента будут добавляться здесь.
    }
}
