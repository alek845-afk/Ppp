@echo off
echo Требуется JDK 8 и установленный Gradle 4.10.3.
gradle --version
if errorlevel 1 exit /b 1
gradle build
if errorlevel 1 exit /b 1
echo Готовый JAR: build\libs\SluzhbaKorony-1.0.0.jar
pause
